#include <stdio.h>

int main()
{
    printf("hello,world!123");

    getchar();
    return 0;
}